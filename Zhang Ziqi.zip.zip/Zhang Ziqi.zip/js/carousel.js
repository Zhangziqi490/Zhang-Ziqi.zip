document.addEventListener('DOMContentLoaded', function () {
    let currentSlide = 0;
    const slides = document.querySelectorAll('.carousel-item');
    const dots = document.querySelectorAll('.dot');
    const totalSlides = slides.length;

    // 轮播图切换逻辑
    function showSlide(index) {
        slides.forEach(slide => slide.classList.remove('active'));
        dots.forEach(dot => dot.classList.remove('active'));

        slides[index].classList.add('active');
        dots[index].classList.add('active');
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % totalSlides;
        showSlide(currentSlide);
    }

    function prevSlide() {
        currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
        showSlide(currentSlide);
    }

    // 添加点击事件监听器
    document.querySelector('.carousel-next').addEventListener('click', nextSlide);
    document.querySelector('.carousel-prev').addEventListener('click', prevSlide);

    // 点击指示点切换轮播图
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            currentSlide = index;
            showSlide(currentSlide);
        });
    });

    // 自动轮播
    setInterval(nextSlide, 5000);

    // 获取搜索按钮和搜索框
    const searchBtn = document.getElementById('search-btn');
    const searchInput = document.getElementById('search-input');
    const searchResultsGrid = document.getElementById('search-results-grid'); // 搜索结果展示区域

    // 搜索按钮点击事件
    searchBtn.addEventListener('click', function() {
        const searchQuery = searchInput.value.trim();
        if (searchQuery) {
            // 调用后端API获取图书数据
            fetchBooks(searchQuery);
        } else {
            alert('请输入搜索内容');
        }
    });

    // 执行搜索操作，向后台发送请求
    function fetchBooks(query) {
        // 后端的搜索接口
        fetch(`/api/booksearch/SearchBooks?query=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                if (Array.isArray(data)) {
                    renderBooks(data);
                } else {
                    console.error('返回的数据不是一个数组', data);
                }
            })
            .catch(error => console.error('搜索错误:', error));
    }

    // 渲染图书列表
    function renderBooks(books) {
        searchResultsGrid.innerHTML = ''; // 清空现有的搜索结果

        if (books.length === 0) {
            searchResultsGrid.innerHTML = '<p>没有找到匹配的图书。</p>';
            return;
        }

        books.forEach(book => {
            const bookCard = document.createElement('div');
            bookCard.classList.add('book-card');
            bookCard.innerHTML = `
                <img src="${book.CoverImage}" alt="${book.Title}">
                <h3>${book.Title}</h3>
                <p>作者: ${book.Author}</p>
                <button>阅读</button>
            `;
            searchResultsGrid.appendChild(bookCard);
        });
    }
});
