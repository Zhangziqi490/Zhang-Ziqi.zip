let  oUl = document.getElementById("cot");
oUl.innerHTML += oUl.innerHTML;
let aLi = document.getElementsByClassName("co");
oUl.style.width = aLi[0].offsetWidth * aLi.length + "px";
let speed = -2;
let move = ()=> {
	if(oUl.offsetLeft < - oUl.offsetWidth/2){
		oUl.style.left = "0";
	}
	if(oUl.offsetLeft > 0){
		oUl.style.left = oUl.offsetWidth/2 + "px";
	}
	oUl.style.left = oUl.offsetLeft + speed + "px";
}
let timer = setInterval(move,20);
oUl.addEventListener('mouseover',function(){
	clearInterval(timer);
});
oUl.addEventListener('mouseout',function(){
	timer = setInterval(move,20);
});
