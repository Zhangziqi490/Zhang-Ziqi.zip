function validateLogin() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    if (username === "123456" && password === "123456") {
        alert("登陆成功！");
        window.location.href = "index.html";
    } else {
        alert("账号或密码错误！");
    }
}